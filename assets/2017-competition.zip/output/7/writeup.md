# [<t style="color: darkgreen;">DARK GREEN</t>] Roll For Initiative

### Problem Description

Lom Tazer now has enough proof to get Darth Von Glue arrested, but the Marquette judges are weird and have strange form to report people. This form requires the user to roll dice combinations instead of the average captcha. If Lom and Chaz cannot find the right combinations Von Glue Will Escape. **To help them write a program to figure out if certain dice combinations are possible.**

The dice used are a set of five alphabetic dice where each die has a capital letter on each of its six sides. When you roll these dice, five letters appear on their top faces and sometimes you can spell a five-letter English word from these letters. You want to know if these five dice can possibly
roll a specific five-letter word. For example, assume the dice contain the following letters on their six sides: Die1: ABGRTY Die2: EGKOWX Die3: ABVCXA Die4: POYEAT Die5: EITYTJ That is, Die1 has the six letters "A", "B", "G", "R", "T", and "Y" on its six sides. With these dice you could roll the word GREAT using a "G" from Die2, an "R" from Die1, an "E" from Die4, an "A" from Die3, and a "T" from Die5. However, you cannot roll the word TIGER using the dice above; while individually these letters appear on some die, it is not possible for all five letters to appear on the top of five dice at the same time. Note that the same letter may appear multiple times on the same die.

* * *


## Writing Your Solution

Enter your solution in the body of this method in the given code skeleton. You can download the skeletons here([java](/download/java/s7), [python](/download/python/s7)).

### Method Signature

Java:

```Java

public static boolean rollDice(String die1,
                               String die2,
                               String die3,
                               String die4,
                               String die5,
                               String word)
```

Python:

```Python

def rollDice(die1, die2, die3, die4, die5, word):

```

### Sample Method Calls

```Java

rollDice("ABGRTY", "EGKOWX", "ABVCXA", "POYEAT", "EITYTJ", "GREAT");
```

Returns: `True`  

```Java

rollDice("ABGRTY", "EGKOWX", "ABVCXA", "POYEAT", "EITYTJ", "TIGER");
```

Returns: `False`

* * *
<p style="page-break-after:always;"></p>

<br />

## Testing your program From the Console

After writing your program into the given code skeleton, test your solution by running the program and entering sample input in the following format.

### Console Input Format

-   The first line will contain a single integer T, representing the number of test cases to follow.
-   For each test case T, The first five lines will contain six-character strings representing dice and the letters on their faces
-   The sixth line will have the string you are checking to see if you can spell the word with the dice

### Assumptions

-   All dice have six sides, thus, six characters
-   The string to check if being spelled will always be five characters long
-   All characters will be uppercase

### Output Format

`rollDice` should return true if the word can be spelled with the given dice, false otherwise

### Sample Run

```Text

Input:

2
ABGRTY
EGKOWX
ABVCXA
POYEAT
EITYTJ
GREAT
ABGRTY
EGKOWX
ABVCXA
POYEAT
EITYTJ
TIGER

Output:

True
False
```
