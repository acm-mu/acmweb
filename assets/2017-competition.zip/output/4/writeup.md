# [<t style="color: Lime;">LIGHT GREEN</t>] -- --- .-. ... .

### Problem Description

As Lom and Chaz continue cooking, they begin to notice one of the lights in the main floor keeps flashing in seemingly random patterns. But after a while, Chaz notices the signal is actually Morse code.

Chaz explains that Morse code was originally created in the mid 1800s to send simple messages through the electric telegraph. Morse code is a representation of plain English, using two simple symbols, commonly vocalized as dit(.), and dot(-).

Chaz is suspicious of these messages and suggests Lom stops cooking for a bit to translate these messages. The flashing is too fast for Lom and Chaz to translate by hand.

Help Lom **decode the message by writing a Morse code to ASCII converter, so he can translate the message.**

Here is a table of Morse code to help you.

| Morse   | .-  | -... | -.-. | -.. | .   | ..-. | --. | .... | ..  | .--- | -.- | .-.. | --  |
| ------- | --- | ---- | ---- | --- | --- | ---- | --- | ---- | --- | ---- | --- | ---- | --- |
| English | A   | B    | C    | D   | E   | F    | G   | H    | I   | J    | K   | L    | M   |

| Morse   | -.  | --- | .--. | --.- | .-. | ... | -   | ..- | ...- | .-- | -..- | -.-- | --.. |
| ------- | --- | --- | ---- | ---- | --- | --- | --- | --- | ---- | --- | ---- | ---- | ---- |
| English | N   | O   | P    | Q    | R   | S   | T   | U   | V    | W   | X    | Y    | Z    |

* * *

## Writing your Solution

Enter your solution in the body of this method in the given code skeleton:

You can download the skeletons here([java](/download/java/s4), [python](/download/python/s4))

#### Method Signature

Java:

```Java

public static String decodeMorse(String morse);
```

Python:

```Python

def decodeMorse(morse):
```

### Samlpe Method Calls

`decodeMorse(".-.");`  
Returns: `R`

`decodeMorse(".... . .-.. .-.. --- / .-- --- .-. .-.. -..");`  
Returns: `HELLO WORLD`

`decodeMorse("-.. .- .-. -.- / .-.. --- .-. -.. / -..- .. -. ..- / ... . -. -.. ... / .... .. ... / .-. . --. .- .-. -.. ... !");`  
Returns: `DARK LORD XINU SENDS HIS REGARDS!`

* * *

<p style="page-break-after:always;"></p>\n\n

## Testing you program from the Console

After writing your program into the given code skeleton, test your solution by running the program and entering sample input in the following format.

### Console Input Format

-   The first line will contain a single integer T, the number of test cases to follow
-   T lines follow, each containing a list of space-separated Morse symbols, this represents one message.
-   If there is a character which does not appear on the table, leave it in the output

### Assumptions

-   `1  < T < 10`
-   Each message will not be longer then English 1000 characters.

### Output Format

The translated English message.

### Sample Run

```Text

Input:

3
.-.
.... . .-.. .-.. --- / .-- --- .-. .-.. -..
-.. .- .-. -.- / .-.. --- .-. -.. / -..- .. -. ..- / ... . -. -.. ... / .... .. ... / .-. . --. .- .-. -.. ... !

Output:

R
HELLO WORLD
DARK LORD XINU SENDS HIS REGARDS!
```
