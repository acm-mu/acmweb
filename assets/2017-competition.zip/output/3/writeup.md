# [<t style="color: Yellow;">YELLOW</t>] One Giant Leap

### Problem Description

Armed with the knowledge of how many ingredients they can grab, Lom and Chaz each use their expansive knowledge of kitchen cuisine to select the perfect mixture of ingredients. Each item of food has placed on it an expiration date, including the year, month, and day on which it will expire. Just as Lom and Chaz are about to begin cooking, the organizers of the competition inform them of a twist: _they are not allowed to use any food which expires during a leap year._

A _leap year_ is a year whose number is perfectly divisible by 4, except years which are both divisible by 100 AND not divisible by 400.

"Who came up with these ridiculous rules?" Lom wondered aloud.
"Well, it could be worse, Lom! We could be dealing with daylight savings time!" Chaz said with a shudder.

Lom and Chaz need your help. **Given a starting and ending year, write a function which will return a list of all of the leap years in between the starting and ending year, not including either the starting year or the ending year.**

* * *

## Writing Your Solution

Enter your solution in the body of this method in the given code skeleton:

You can download the skeletons here([java](/download/java/s3), [python](/download/python/s3))

### Method Signature

Java:

```Java

public static int [] findLeapYears(int startingYear, int endingYear);
```

Python:

```Python

def findLeapYears(startingYear, endingYear):
```

### Sample Method Calls

`findLeapYears(1967, 2004);`  
Returns: `[1968, 1972, 1976, 1980, 1984, 1988, 1992, 1996, 2000]`

`findLeapYears(1299, 1337);`  
Returns: `[1304, 1308, 1312, 1316, 1320, 1324, 1328, 1332, 1336]`

* * *

<p style="page-break-after:always;"></p>\n\n

## Testing your Program from the Console

After writing your program into the given code skeleton, test your solution by running the program and entering sample input in the following format.

### Console Input Format

-   The first line will contain a single integer T, this represents the number of test cases to follow.
-   T lines follow, each contains a integer S and a integer E. S represents the starting year, and E represents the ending year.

### Assumptions

-   `startingYear` is a valid four-digit calendar year between 1000 and 9999
-   `endingYear` is a valid four-digit calendar year between 1000 and 9999, which is greater than or equal to the value of `startingYear`

### Output Format

The function findLeapYears should return an integer array containing all of the leap years between startingYear and endingYear.

### Sample Run

```Text

Input:

2
1967 2004
1299 1337

Output:

1968, 1972, 1976, 1980, 1984, 1988, 1992, 1996, 2000
1304, 1308, 1312, 1316, 1320, 1324, 1328, 1332, 1336

```
