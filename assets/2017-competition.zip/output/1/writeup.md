# [<t style="color: Red;">RED</t>] Sunrise

* * *

### Problem Description

The sun rises brightly on the morning of the Marquette Cooking Competition(MCC), Wisconsin's premier competition for the state's strongest young chefs. Lom Tazer and his trusty sous-chef Chaz O'Rabbit have entered this competition to learn more about cooking, as well as have fun. At the same time, Darth Von Glue is plotting something sinister.

When Lom woke up this morning he realized that his ingredient calculator had broken and now outputs 42 no matter what the input is. Without his ingredient calculator Lom can't work as fast, and that could be the difference between a win and a loss at the MCC.

To help Lom **write a function to calculate mathematical equations.**

Chaz suggests that if Lom enters a 0 as the divisor, the calculator should return zero.

* * *

## Writing Your Solution

Enter your solution in the body of this method in the given code skeleton:

You can download the skeletons here([java](/download/java/s1), [python](/download/python/s1))

### Method Signature

Java:

```Java

public static int calculate(int left, String op, int right)
```

Python:

```Python

def calculate(left, op, right):
```

### Sample Method Calls

`calculate(1, "+", 1)`  
Returns: `2`

`calculate(4, "*", 2)`  
Returns: `8`

`calculate(151, "/", 0)`  
Returns: `0`

* * *

<p style="page-break-after:always;"></p>\n\n

## Testing Your Program from the Console

### Console Input Format

-   n Number of Tests
-   an expression in the form of `left op right`
    -   where `left` and `right` are integers  
    -   and `op` is a string representing the four main mathematical operators.  
        -   +  
        -   -  
        -   /  
        -   *  

### Assumptions

-   `left < 10^6`
-   `right < 10^6`
-   `op is in [+, -, /, *]`

### Console Output Format

The result of the mathematical expression, on a single line

### Sample Run

```Text
Input:

3
1 + 1
4 * 2
151 / 0

Output:

2
8
0
```
