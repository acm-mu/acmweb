# [<t style="Color: Blue;">BLUE</t>] All your base are belong to us

### Problem Description

Now that Darth Von Glue’s secret Morse code has been broken, Lom and Chaz realize they also must exchange secret messages to discuss how they will foil Darth Von Glue’s evil plot. Von Glue, being the nefarious mastermind he is, realizes they must be talking in code now. To prevent Von from reading this correspondence we must encode our messages in a different numerical base. Your task is to convert a decimal base integer to any other specified numerical base.

The default base is decimal also know as base 10. For instance, take 234, which can be thought of as follows:

| <u>2</u> | <u>3</u> | <u>4</u> |
| -------- | -------- | -------- |
| 10^2     | 10^1     | 10^0     |

Which equates to

```Text
234=2*10^2 + 3*10^1 + 4*10^0.
```

So, you may be wondering then, are there other bases outside of base 10? Yes.  In fact, a common one you may have heard of is binary or base 2. If we wanted to write 234 in base 2 it would be as follows:

For example:

| <u>1</u> | <u>1</u> | <u>1</u> | <u>0</u> | <u>1</u> | <u>0</u> | <u>1</u> | <u>0</u> |
| -------- | -------- | -------- | -------- | -------- | -------- | -------- | -------- |
| 2^7      | 2^6      | 2^5      | 2^4      | 2^3      | 2^2      | 2^1      | 2^0      |

This equates to:

```Text
234=(1*2^7)+(1*2^6)+(1*2^5)+(0*2^4)+(1*2^3)+(0*2^2)+(1*2^2)+(1*2^1)+(0*2^0).
```

So given what you know about base 10 and the binary shown above, a pattern that can be identified is that a number in any position can only go up to the (base# - 1) before it adds a 1 in the next position. A more straightforward way might be to count to 9 before you get to 10 or 19 before 20 or 99 before 100. Another key thing is what to do when you have a base greater than 10. That is where it gets tricky so instead of numerical digits you use letters. This Legend should give you a clearer idea.

Legend

| Letter | Number |
| ------ | ------ |
| A      | 10     |
| B      | 11     |
| C      | 12     |
| D      | 13     |
| E      | 14     |
| F      | 15     |

* * *

<p style="page-break-after:always;"></p>\n\n

## Writing your solution

Enter your solution in the body of this method in the given code skeleton:

You can download the skeletons here([java](/download/java/s5), [python](/download/python/s5))

### Method Signature

Java:

```Java
public static char[] baseConvert(long num, int base);
```

Python:

```Python
def baseConvert(num, base):
```

### Sample Method Calls

`baseConvert(234,2);`  
Returns: `[1,1,1,0,1,0,1,0]`  

`baseConvert(234,16);`  
Returns: `[0,0,0,0,0,0,E,A]`  

`baseConvert(234,8)`  
Returns: `[0,0,0,0,0,3,5,2]`  

* * *

## Testing your program from the Console

After writing your program into the given code skeleton, test your solution by running the program and entering sample input in the following format.

### Console Input Format

-   The first line will contain a single integer T, this represents the number of test cases to follow.
-   Each line T will contain the number `num`, and the base `base` separated by spaces.

### Assumptions

Base ten number `0 <= num <= 4294967295`  
Given base `2 <= base <= 16`

### Console Output Format

The function baseConvert should return a character array of length 8 with each index in the correct base.

### Sample Run

```Text
Input:
3
234 2
234 16
234 8

Output:
[1,1,1,0,1,0,1,0]
[0,0,0,0,0,0,E,A]
[0,0,0,0,0,3,5,2]
```
