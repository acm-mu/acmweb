# [<t style="color: purple;">PURPLE</t>] Off The Grid

### Problem Description

After translating an intercepted message, Chaz and Lom learn that Darth Von Glue has poisoned several of the ingredients with the hope of poisoning anyone who eats the dishes. Chaz and Lom quickly run to the pantry and notice all the food items have a peculiar pattern of 16 numbers on the bottom. They realize this must be Darth Von Glue’s way of secretly noting which ingredients are poisoned.

Lom thinks back to his first interaction with Darth Von Glue, and recalls Darth was working on a sudoku puzzle with fervor. It dawns on Lom and Chaz that Darth Von Glue is likely using mini-sudokus to mark which ingredients are poisoned. Fortunately, Chaz and Lom know that a mini-sudoku is a 4x4 square of numbers where each row, column, and quadrant of numbers has the integers 1 through 4 without any repeats.

Chaz and Lom grab the open container of crackers that Chaz had been snacking on earlier and realize that the sudoku on the bottom had an invalid solution. Since Chaz is still living, they determine a valid sudoku indicated a poisoned ingredient.

To help Lom and Chaz quickly determine the safe ingredients, **write a program to determine if the 4x4 pattern is a valid mini-sudoku solution.**

For Example:  
```Text

valid Solution:				Invalid Solution:
|  1  2  |  3  4  |			|  1  2  |  1  4  |
|  3  4  |  1  2  |			|  3  4  |  1  2  |
-------------------			-------------------
|  2  1  |  4  3  |			|  2  1  |  4  3  |
|  4  3  |  2  1  |			|  4  2  |  3  1  |
```

* * *

## Writing Your Solution

Enter your solution in the body of this method in the given method signature. You can download the skeletons here([java](/download/java/s6), [python](/download/python/s6)).

### Method Signature

Java:

```Java
public static bool isValidSolution(int[][] solution)
```

Python:

```Python
def isValidSolution(solution):
```

### Sample Method Calls


`int solution[][] = {{1,2,3,4},{3,4,1,2},{2,1,4,3},{4,3,2,1}};`  
`isValidSolution(solution);`  
Returns: `True`

`int solution[][] = {{1,2,1,4},{3,4,1,2},{2,1,4,3},{4,2,3,1}};`  
`isValidSolution(solution);`  
Returns: `False`

* * *

<p style="page-break-after:always;"></p>\n\n

## Testing Your Program From the Console

After writing your program into the given code skeleton, test your solution by running the program and entering sample input in the following format.

### Console Input Format

-   The first line will contain a single integer T, representing the number of test cases to follow.
-   For each test case T, there are four lines of input, where each row has four space-separated numbers that represent one row of the solution

### Assumptions

- Input is a 4x4 grid
- All numbers input are integers `<= 4` and `>= 1`

### Console Output Format

True or False based on the validitity of the solution.

### Sample Run

```Text

Input:

2
1 2 3 4
3 4 1 2
2 1 4 3
4 3 2 1
1 2 1 4
3 4 1 2
2 1 4 3
4 2 3 1

Output:

True
False


```
